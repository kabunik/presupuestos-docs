# PAQUETE DE INTEGRACIÓN — Motor de Presupuesto de Montaje
### Para el equipo de desarrollo del Generador de IFC y Presupuestos · v1.0 · METALITEC/Grupo Baysa

## 1. Qué es este motor
Pipeline en Python 3.10+ que convierte un IFC de estructura metálica en un presupuesto de montaje
en **USD** con dispersión declarada, y cierra un **lazo de co-optimización** con fabricación
(lotes ≤ 50 t, frontera costo–tiempo). Cuatro ejecutables, sin servicios externos, todo por
archivos JSON (contrato en `docs/Especificacion_Integracion_FAB_MONTAJE.md`).

Dependencias: `ifcopenshell`, `numpy`, `openpyxl`  →  `pip install ifcopenshell numpy openpyxl`

## 2. Los 4 ejecutables (scripts/)

### 2.1 extract_montaje.py — Ingesta IFC → dataset canónico
```
python3 extract_montaje.py <modelo.ifc> --out dataset_montaje.json
```
- Soporta Tekla IFC2X3/IFC4/IFC4X3, pset propio `Pset_BAYSA_Cubicacion`, y modelos de solo
  geometría (ReferenceView): peso por pset → volumen pset → **volumen analítico** (perfil×profundidad,
  malla, disco barrido; NO usa el motor de geometría de ifcopenshell por rendimiento).
- Salida: tonelaje por tipo/material/categoría, histograma de izaje, pick_max_kg, pernos de campo
  segmentados (A307/A325-A490/F1554) con método de conteo, altura, `banderas_gate` (lista de strings).
- Códigos de retorno: 0 OK; falla dura solo si el IFC no abre. Un dataset con banderas es válido.

### 2.2 preparar_montaje.py — Driver determinista (pre-figuras)
```
python3 preparar_montaje.py dataset_montaje.json --params params.json --out prefiguras_montaje.json
```
- `params.json` = overrides de los DEFAULTS (dict al inicio del script; fuente de verdad de parámetros).
- Jerarquía de tornillería: PERNOS_SEGMENTO/PERNOS_CAMPO_TOTAL (real) > PERNOS_POR_CONEXION
  (despiece fab) > estimada por tonelaje (si densidad < UMBRAL_PERNOS_PZA_T) > conteo del modelo.
- **Soldadura de campo: verificación SIEMPRE obligatoria** — estado INGRESADA / PENDIENTE /
  NO DISPONIBLE en `soldadura_campo.estado`. Integrar en UI como semáforo bloqueante.
- Incluye factores de realidad: reposicionamientos de grúa, rampa de aprendizaje, ausentismo,
  PF&D, doble manejo, temporales/obra falsa, calendario (lluvia+festivos), NCR, y bandas por
  partida → `resumen.dispersion_esperada_pct`.

### 2.3 motor_lazo.py — Lazo de co-optimización FAB↔MONTAJE
```
python3 motor_lazo.py --prefiguras prefiguras_montaje.json --dataset dataset_montaje.json \
  --tarifas tarifas_taller.json [--cronofab cronograma_fab.json]
```
- Requiere `tarifas_taller.json` (esquema §4 de la spec). Sin él NO correr: no hay comparación.
- Salidas: `frontera_lazo.json` (escenarios × loteos, recomendado = mín USD que cumple T_max) y
  `lotes_montaje.json` (retorno a fabricación, esquema §6).
- Chequeo O2: valida `fecha_liberacion` de cada lote fab contra pull dates; lista infactibles.

### 2.4 retro_montaje.py — Ciclo de retroalimentación
```
python3 retro_montaje.py plantilla prefiguras_montaje.json --out RETRO_<proy>.xlsx
python3 retro_montaje.py cerrar RETRO_<proy>.xlsx --hist calibracion_hist.json --out calibracion_actualizada.json
```
- `calibracion_hist.json` es acumulativo (histórico multi-proyecto) y COMPARTIDO con fabricación
  (lee `ncr_hh` y causas). La calibración propuesta NO se auto-aplica: requiere firma (flujo UI:
  mostrar diff → aprobar → mergear a params del siguiente proyecto).

## 3. Contrato de datos (esquemas/)
JSON de ejemplo válidos, uno por esquema de la spec (§1–§8). Reglas duras:
- Moneda **USD** en todo importe (declarar `fx_usado` si se convirtió).
- Identidad de pieza: par `{marca, guid_ifc}` en cualquier lista de piezas.
- `campo.kg_aporte = 0` es un dato; ausencia del archivo es bandera bloqueante.
- G1: si `bom_contractual.toneladas_contractuales` difiere del IFC > ±3%, el pipeline se detiene.

## 4. Qué debe construir el lado del Generador (backlog mínimo)
1. Export de los 5 JSON (§1–5 de la spec) desde el despiece/cronograma de fabricación.
2. Template único de export IFC en Tekla (checklist §10 de la spec) — CRÍTICO: Welds:On, Bolts:On,
   Assemblies:On, pset con Marca. Sin esto los datos degradan a estimaciones.
3. Ingesta de los 3 JSON de retorno (§6–8): lotes_montaje (reprogramar producción),
   señales de ingeniería de valor (a diseño), calibracion_hist (NCR a calidad).
4. Un job de validación de esquemas (los ejemplos de esquemas/ sirven como fixtures de test).

## 5. Convenciones que NO se rompen
- Excel: azul=entradas, verde=links, amarillo=supuestos, utilidad en azul; tokens {KEY};
  prohibido XLOOKUP/FILTER/UNIQUE/SORT/SEQUENCE (compatibilidad LibreOffice); jamás escribir
  sobre celdas combinadas (usar ancla).
- Toda estimación automática queda MARCADA (fuente + bandera); el valor real siempre puede
  sustituirla por parámetro.
- Decisiones de izaje/secuencia/tonelaje = firma humana (Daniel). El software propone, no cierra.

## 6. Smoke test incluido
```
cd ejemplos && bash smoke_test.sh    # corre pipeline completo con MAILENA y verifica salidas
```

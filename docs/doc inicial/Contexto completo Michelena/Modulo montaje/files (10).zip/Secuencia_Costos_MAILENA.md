# SECUENCIA DE MONTAJE POR TIPO DE OBRA + COSTOS — MAILENA_EWS (USD)

```
====================================================================================================
SECUENCIA DE MONTAJE POR TIPO DE OBRA (DOMO RADIAL) + COSTOS ASOCIADOS — MAILENA_EWS · USD
====================================================================================================
# Fase                                 pzas    ton  grua-h  HH fase   USD MO USD equipo  USD FASE
1 Placas base + anclas + grout           24    8.4    13.4      174    2,776        643     3,419
2 Columnas (anillo ext -> int)           24  235.2    29.4      174    2,776      4,851     7,627
3 Trabes de cinturon                     32   25.6    48.8      200    3,202      8,052    11,254
4 Trabes principales                     16   18.1    24.4       82    1,313      4,026     5,339
5 Trabes radiales                         8    8.1    12.2       41      657      2,013     2,670
6 DOMO (trabes con obra falsa)            8   17.3    12.2     1488   23,801      2,013    25,814
7 Anillo interior                        16    2.3    19.6       68    1,083      3,234     4,317
8 Vigas secundarias (manlift)           128   20.4   156.8      541    8,662      7,526    16,188
9 Postes/fachada (manlift, paralelo)     56   25.6    40.6      153    2,446      1,949     4,394
----------------------------------------------------------------------------------------------------
  SUBTOTAL SECUENCIA (directo por fase)  312  361.2   357.4     2920                        81,023

  PARTIDAS TRANSVERSALES (todo el proyecto):
    Reposicionamientos de grua (5 x 3h)                      2,475
    Descarga de material (17 viajes)                         3,876
    Doble manejo / re-acomodos                                 374
    NCR fabricacion en campo                                   299
    Topografia (14.2 sem + 2 previas)                       14,980
    Rampa aprendizaje + PF&D + ausentismo                   12,946
    Subtotal transversales                                  34,950

  RENTAS FIJAS DE EQUIPO (telehandler, manlifts, soldadura, gen, oficinas, EPP): 67,541
  DIRECCION DE OBRA E INDIRECTOS: 70,610

  SUBTOTAL COSTO                                           254,124
  Contingencia 10%                                          25,412
  COSTO TOTAL                                              279,536
  UTILIDAD 12% [AZUL]                                       33,544
  PRECIO VENTA                                             313,081   (867 USD/t)

  Notas de fase: F1 nivelacion+grout+topografia de anclas | F2 aplome de 6 porticos x 3h + arriostre parcial | F6 obra falsa 600 HH + soldadura campo 846.5 HH
```

## Lectura de la secuencia (tipo de obra: DOMO RADIAL)
- **La fase 6 (DOMO) concentra el 32% del costo directo de secuencia** (25.8 kUSD) con solo 8 piezas y 17.3 t: obra falsa (600 HH) + toda la soldadura de campo (846.5 HH). Es LA fase a optimizar: pre-armado en piso y/o asientos temporales.
- Las fases 8-9 (secundarias+postes, 184 pzas) van por **manlift en paralelo** — no compiten por la grua pesada.
- La grua de 90-110 t solo la exigen las fases 2-6 (~127 grua-h): ventana de ~4 semanas, no todo el proyecto.

## Por que este total (313k / 867 USD/t) difiere del presupuesto por-recurso (426k / 1,180 USD/t)
Son dos metodos que deben converger y su brecha ES informacion:
- **Por fase** (este): grua por HORA trabajada + HH puras -> el costo 'ideal' sin ociosidad.
- **Por recurso** (S8): rentas MENSUALES completas + cuadrillas con holgura -> lo que de verdad se paga.
- La brecha (~113 kUSD, 26%) es el costo de la **ociosidad de recursos** (grua al 28% de utilizacion, cuadrillas dimensionadas al pico). La oferta se hace con el por-recurso (conservador); el por-fase dice DONDE atacar: acortar la ventana de la grua grande y nivelar cuadrillas cerraria gran parte de esa brecha.


# Paquete Base de Desarrollo — Sistema de Presupuesto Automático · v1.3
Metalitec Zapotlán (Grupo Baysa) · 14 de agosto de 2026

## Qué cambió en v1.3
Se incorporó la **Memoria del Estimador de Horas Hombre** (parámetros vigentes de la planta real):
criterio paramétrico de HH por pieza (ruta primaria del motor M2), costo HH operativo $265 (reconciliado
con abril 2026), márgenes ×1.18/×1.21, capacidad 46 propios / ~25,000 HH con contratistas, tarifas de
contratistas por complejidad, factor de obra 60%, reglas de transporte, y 6 correcciones de coherencia
nuevas (13–18 del Documento Maestro). Reglas nuevas R21–R26.

## Contenido
| Archivo | Rol |
|---|---|
| Documento_Maestro_Conceptos_Presupuesto_v1.3.docx | Especificación funcional (conceptos 1–27, 18 correcciones, glosario) |
| Especificacion_Tecnica_Sistema_Presupuestos_v1.3.docx | Especificación técnica (M1–M7, modos A/B/C, R1–R26, pipeline V1–V7) |
| Grafico_Rentabilidad_Presupuesto.html | Referencia de UI interactiva (2 pestañas, presets Didáctica/Metalitec) |
| datos_semilla/*.json (6) | Configuración inicial de los motores (ver 11.8 de la Esp. Técnica) |
| archivos_fuente/Ejemplo_Presupuesto_Sistema_DM.xlsx | Hoja fuente del modo A (cascada de pesos) |
| archivos_fuente/Informe_Factores_Presupuesto_Estructuras_Metalicas.xlsx | ESTIMACIÓN DE DESPERDICIOS (último, AISC 303-22) |
| archivos_fuente/Familia_de_Estructuras_v4_Motor_HHton_BudgetEngine.xlsx | Base de rendimientos (Budget Engine v4.1) |
| archivos_fuente/251601_Teleferico_Hacienda_Presupuesto_ModoC.xlsx | Caso real del modo C (homologación de inventario) |
| archivos_fuente/PROGRAMA_FABRICACION_CHABACANO_Rev2.xlsx | CARGA DE PLANTA / programa de fabricación (último disponible en Drive) |

## Decisiones pendientes de Daniel (bloquean partes del alcance)
1. Factor AWS D1.8: ×1.25 solo porción CJP (implementado) o total del elemento.
2. Composición exacta del costo fijo comercial $4.75M/mes (corrección 14).
3. Consumibles: composición del $2.4/kg vs $1.35/kg real de abril (corrección 17).
4. Valores ESTIMADO del Budget Engine: IN-04 (50.9) y PA-02 (61.2 HH/ton).
5. Mapa de puestos MOD/MOI y hito que acredita "kilos fabricados".
6. Contratistas: implantar reporte de HH gastadas/ganadas.

## Archivos que faltan (los adjuntará Daniel)
Layout de planta · lista de equipos con capacidades · Motor_Pintura_Desperdicios.xlsx ·
desperdicio de materiales real de proyectos cerrados · gráficos originales de rentabilidad ·
P&L de 2–3 meses adicionales · asistencia semanal y HH de contratistas · BD de rendimientos medidos ·
IFC + BOM de ejemplo (Tekla) · inventario de plancha/perfiles · carga de planta vigente a 6 meses ·
0426 Costos planta Zapotlán.xlsx (fuente contable original).
